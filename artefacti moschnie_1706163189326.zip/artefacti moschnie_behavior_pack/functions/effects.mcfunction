effect @p strength 9999999 4 true
effect @p speed 9999999 4 true
effect @p resistance 9999999 2 true
effect @p jump_boost 9999999 4 true
effect @p regeneration 9999999 4 true
effect @p health_boost 9999999 4 true
effect @p haste 9999999 4 true
effect @p village_hero 9999999 255 true