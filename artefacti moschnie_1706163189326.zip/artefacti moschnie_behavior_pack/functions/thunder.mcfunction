summon lightning_bolt
effect @p slowness 5 255 true