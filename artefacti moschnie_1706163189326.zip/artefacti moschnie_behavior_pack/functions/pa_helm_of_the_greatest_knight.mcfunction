replaceitem entity @s slot.armor.head 1 pa:helm_of_the_greatest_knight
replaceitem entity @s slot.weapon.mainhand 0 air