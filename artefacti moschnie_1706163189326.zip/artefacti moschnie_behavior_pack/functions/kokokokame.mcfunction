fill ~5 ~ ~5 ~-5 ~5 ~-5 air replace stone
fill ~5 ~ ~5 ~-5 ~5 ~-5 air replace deepshale
fill ~5 ~ ~5 ~-5 ~5 ~-5 air replace gravel